# Write a program called alice_words.py 
# that creates a text file named alice_words.txt containing
# an alphabetical listing of all the words, and the number 
# of times each occurs, in the text version of Alice’s Adventures in Wonderland. 


def get_lines(filename):
    pass


def get_word_count(lines):
    pass

def write_file(filename):
    pass