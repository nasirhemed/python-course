## Create a class Time to display time

class Time:

    def __init__(self, hr, min, sec):
        pass

    def __str__(self):
        pass 
    
    def cmp(self, other):
        # Compare two times and see which one is bigger
        # Return -1 if self < other 
        # Return 1 if self > other
        # Return 0 if self == other
        pass 

    def __eq__(self, other):
        pass 

    def __le__(self, other):
        pass 

    def __lt__(self, other):
        pass 

    def __ge__(self, other):
        pass 

    def __gt__(self, other):
        pass 