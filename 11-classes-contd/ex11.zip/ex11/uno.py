# Uno game: TODO in class 

class Card:
    pass 


class Deck:
    pass 