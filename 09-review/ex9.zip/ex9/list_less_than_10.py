def print_less_than_10(lst):
    """
    Given a list, print out the numbers that are less than 10
    
    """
    pass