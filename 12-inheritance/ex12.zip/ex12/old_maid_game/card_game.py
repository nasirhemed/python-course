class CardGame:
    def __init__(self):
        self.deck = Deck()
        self.deck.shuffle(