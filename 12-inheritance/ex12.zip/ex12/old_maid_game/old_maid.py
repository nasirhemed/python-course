from deck import Deck 
from card import Card 
from hand import Hand 
from card_game import CardGame

class OldMaidHand(Hand):

    def remove_matches(self):
        pass

class OldMaidGame(CardGame):

    def play(self):
        pass