# Write a function that takes user input and checks if user input is valid
# If user input is not valid then print wrong choice
# User input must be between 0 and 10
def user_choice():
    '''
    User inputs a number (0-10) and we return this in integer form.
    No parameter is passed when calling this function.
    '''
    choice = input("Please input a number (0-10): ")

    # First, convert the choice into a number
    # TODO: Your code here
    
    # Second, check if the number is between 0 and 10
    # if it is then return that number
    # Hint: use condition to check if number >= and number <= 10
    # TODO: Your code here
    

    # Third: else case: print("wrong choice)


user_choice()