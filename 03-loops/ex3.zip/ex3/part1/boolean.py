import doctest

def is_even(num):
    """
    Given a number, return True if it is even
    if it is odd, return False


    >>> is_even(4)
    True
    >>> is_even(5)
    False
    >>> is_even(0)
    True

    """

def sleep_in(weekday, vacation):
    """
    The parameter weekday is True if it is a weekday, 
    and the parameter vacation is True if we are on vacation. 
    We sleep in if it is not a weekday or we're on vacation. 
    Return True if we sleep in.

    >>> sleep_in(False, False)
    True
    >>> sleep_in(True, False)
    False
    >>> sleep_in(False, True)
    True
    """

    pass # TODO: Remove this and write your code

def parrot_trouble(talking, hour):
    """
    We have a loud talking parrot. 
    The "hour" parameter is the current hour time in the range 0..23. 
    We are in trouble if the parrot is talking and the hour is before 7 or after 20. 
    Return True if we are in trouble.


    >>> parrot_trouble(True, 6)
    True
    >>> parrot_trouble(True, 7)
    False
    >>> parrot_trouble(False, 6)
    False

    """

    pass # TODO: Remove this and write your code



doctest.testmod()