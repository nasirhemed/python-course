import turtle

def draw_square(t, x, y, size):
    t.penup()
    t.setpos(x, y)
    t.pendown()

    t.setheading(0)
    
    for i in range(4):
        t.forward(size)
        t.left(90)


a = turtle.Turtle()

# How can I improve this ? 
draw_square(a, 0, 0, 10)
draw_square(a, 50, 0, 10)
draw_square(a, 100, 0, 10)
draw_square(a, 150, 0, 10)
draw_square(a, 200, 0, 10)
draw_square(a, 250, 0, 10)
draw_square(a, 300, 0, 10)
draw_square(a, 350, 0, 10)

