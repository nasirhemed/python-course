import random 

my_number = random.randint(1, 100)

# TODO: Write a program that implements a guessing game
# my_number is some random number that we have to guess
# my_number is between 1 and 100

# We want to ask the user to guess my_number
# If the number is too high, tell the user number is too high and ask again
# If the number is too low, tell the user the number is too low and ask again
# If the number is exactly equal to my_number, then tell the user that he guessed and stop the program


# Hint: We will need a while loop to keep asking the user
# When the user gives us a number, we will convert the number
# We will need to have 3 cases:
    # Too high
    # Too low
    # Equal